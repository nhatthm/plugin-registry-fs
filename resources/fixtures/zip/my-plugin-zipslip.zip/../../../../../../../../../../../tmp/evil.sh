#!/bin/bash

echo "evil"
